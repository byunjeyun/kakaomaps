package com.comgen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComgenApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComgenApplication.class, args);
	}

}
